This is a very simple DownloadLoader
